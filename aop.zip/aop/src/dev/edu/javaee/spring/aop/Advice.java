package dev.edu.javaee.spring.aop;

public interface Advice {

}
