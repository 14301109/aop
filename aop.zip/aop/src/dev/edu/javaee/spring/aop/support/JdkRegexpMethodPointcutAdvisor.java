package dev.edu.javaee.spring.aop.support;

import java.util.LinkedList;
import java.util.List;

import dev.edu.javaee.spring.aop.Advice;
import dev.edu.javaee.spring.aop.ClassFilter;
import dev.edu.javaee.spring.aop.Pointcut;

public class JdkRegexpMethodPointcutAdvisor extends AbstractPointcutAdvisor {

	private final JdkRegexpMethodPointcut pointcut = new JdkRegexpMethodPointcut();
	private Advice advice;
	private List<String> patterns=new LinkedList<>();
	@Override
	public Pointcut getPointcut() {
		return this.pointcut;
	}

	public void setClassFilter(ClassFilter classFilter) {
		this.pointcut.setClassFilter(classFilter);
	}
	
	/*public void setPattern(String mappedName) {
		this.pointcut.setPattern(mappedName);
	}*/
	
	public void setPatterns(List<String> patterns) {
		this.pointcut.setPatterns(patterns);
	}

}
