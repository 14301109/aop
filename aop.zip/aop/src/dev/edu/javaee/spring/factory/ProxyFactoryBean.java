package dev.edu.javaee.spring.factory;

import java.util.List;

import dev.edu.javaee.spring.aop.Advisor;
import dev.edu.javaee.spring.aop.framework.ProxyFactory;

public class ProxyFactoryBean {
	private String proxyInterfaces;
	private Object target;
	private Object[] interceptorNames;
	private ProxyFactory proxyFactory = new ProxyFactory();
	public String getProxyInterfaces() {
		return proxyInterfaces;
		
	}
	public ProxyFactory getProxyFactory() {
		return proxyFactory;
	}
	public void setProxyFactory(ProxyFactory proxyFactory) {
		this.proxyFactory = proxyFactory;
	}
	public void setProxyInterfaces(String proxyInterfaces) throws ClassNotFoundException {
		this.proxyInterfaces = proxyInterfaces;
		this.proxyFactory.setInterfaces(Class.forName(proxyInterfaces));
	}
	public Object getTarget() {
		return this.proxyFactory.getTargetSource().getTarget();
	}
	public void setTarget(Object target) {
		this.target = target;
		this.proxyFactory.setTarget(target);
	}
	public List<Advisor> getInterceptorNames() {
		return this.proxyFactory.getAdvisors();
	}
	public void setInterceptorNames(Object[] interceptorNames) {
		this.interceptorNames = interceptorNames;
		int length=interceptorNames.length;
		for(int i=0;i<length;i++){
			this.proxyFactory.addAdvisor((Advisor) interceptorNames[i]);
		}
		
	}
	public Object getProxy(){
		
		return this.proxyFactory.getProxy();
		
	}

}
