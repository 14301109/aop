package test.edu.javaee.spring.aop;

public interface ISubject {
	void printFirstMessage();
	void printSecondMessage();
}
